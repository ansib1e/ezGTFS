##
## ********************************************
## *                   ezGTFS                 *
## *          GTFS Dataset Generator          *
## *                 Version 1.0              *
## ********************************************
##

# ansib1e - May 15, 2020 to ....
# Python 3.7

# Imports outside modules
import os

# Import functions and classes from within the ezGTFS
from ezGTFS.app import gtfs_step1 as gtfs_step1
from ezGTFS.app import gtfs_step2 as gtfs_step2
from ezGTFS.app import gtfs_step3 as gtfs_step3
from ezGTFS.app import gtfs_step4 as gtfs_step4


# ================ CREATE NEW GTFS ===============================================================================================

# =============== Main CREATE function / logic loop =========================================================================================================


def create_GTFS_files(general_input_filepath, stops_filepath, user_choice):
    # (!) Assumes that there is only 1 route (!)

    # Step 1. Parse input.csv files to General Pandas DataFrames
    print('\n\n[*] STEP 1: Parse Input -> GPD...')
    general_dataframe = gtfs_step1.parse_input_csv(general_input_filepath)
    stops_input_dataframe = gtfs_step1.parse_input_csv(stops_filepath)

    # Step 2. General DataFrame -> Multiple individual DFs
    print('\n\n[*] STEP 2: Calculate/Parse -> Individual DFs...')
    parsed_agency_DF = gtfs_step2.parse_agency_fromGDF(general_dataframe)  # Extracted a COMPLETED 'agency.txt' in the form of a DF from the General DataFrame
    parsed_calendar_DF = gtfs_step2.parse_calendar_fromGDF(
        general_dataframe)  # Extracted a COMPLETED 'calendar.txt' in the form of a DF from the General DataFrame
    parsed_routes_DF = gtfs_step2.parse_routes_fromGDF(general_dataframe)  # Extracted a COMPLETED 'routes.txt' in the form of a DF from the General DataFrame
    parsed_stops_DF = gtfs_step2.parse_stops_fromGDF(stops_input_dataframe)  # Extracted a COMPLETED 'stops.txt' in the form of a DF from the General Da
    parsed_trips_DF = gtfs_step2.parse_trips_fromGDF(general_dataframe,
                                                     stops_input_dataframe)  # Extracted a COMPLETED 'trips.txt' in the form of a DF from the General Da
    parsed_stoptimes_DF = gtfs_step2.parse_stoptimes_fromGDF(general_dataframe, stops_input_dataframe)
    # stop_times.txt

    # Step 3. Append Agency class object to agency_df
    print('\n\n[*] STEP 3: Output to CSV...')
    gtfs_step3.parse_outputCSV_from_indvDF(parsed_agency_DF, 'agency.txt', user_choice)
    gtfs_step3.parse_outputCSV_from_indvDF(parsed_calendar_DF, 'calendar.txt', user_choice)
    gtfs_step3.parse_outputCSV_from_indvDF(parsed_routes_DF, 'routes.txt', user_choice)
    gtfs_step3.parse_outputCSV_from_indvDF(parsed_stops_DF, 'stops.txt', user_choice)
    gtfs_step3.parse_outputCSV_from_indvDF(parsed_trips_DF, 'trips.txt', user_choice)
    gtfs_step3.parse_outputCSV_from_indvDF(parsed_stoptimes_DF, 'stop_times.txt', user_choice)

    # Step 4
    print('\n\n[*] STEP 4: CSV -> TXT & removing CSV...')
    gtfs_step4.csv_to_text(user_choice)
    gtfs_step4.delete_csv_final_step(user_choice)
def main():
    # Run create new GTFS from user_inputs
    print("GTFSed version 1.0\nA tool to create new GTFS dataset given user-specified parameters")
    choice_bool = True
    while choice_bool is True:
        user_choice = input(
            "Please enter the output GTFS dataset name. The final .txt files will be saved in a folder that will be created using this name...: ")
        if not os.path.exists('output_GTFS/' + user_choice):
            break
        print("\n\t[!]That output folder name either already exists or was not inputted correctly. Please enter a valid name for a (new) GTFS dataset...\n")
    create_GTFS_files('../inputs/GTFS_input.csv', '../inputs/GTFS_stops_input.csv', user_choice)
    print("GTFS Generation finished!")





if __name__ == '__main__':
    main()
