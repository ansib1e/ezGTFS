import pandas

def parse_input_csv(filepath):
    print("\t[*]Parsing {} for required field inputs...".format(filepath))
    dataframe = pandas.read_csv(filepath)
    print("\t\t[+] Successfully extracted .csv data from {}".format(filepath))
    return dataframe
