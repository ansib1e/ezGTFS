# ================ Step 2. General Pandas DataFrame => Class Objects (indv ROW) => Inividual DataFrames ===============================================================================================
# ================ Step 2.b Class Objects => Pandas DataFrame (add Row to DF)  ===============================================================================================
# START agency.txt -------------------------------------------------------------------------------------------------------------------------------------------------------
import pandas
import math
from tqdm import tqdm
from ezGTFS.app.gtfs_definitions import Agency
from ezGTFS.app.gtfs_definitions import Calendar
from ezGTFS.app.gtfs_definitions import Routes
from ezGTFS.app.gtfs_definitions import Stops
from ezGTFS.app.gtfs_definitions import StopTimes
from ezGTFS.app.gtfs_definitions import Trips

tqdm.pandas()

def to_seconds(timestr):
    seconds= 0
    for part in timestr.split(':'):
        seconds= seconds*60 + int(part)
    return seconds

def to_datetime(seconds):
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    return "%d:%02d:%02d" % (hour, minutes, seconds)

# START agency.txt ------------------------------------------------------------------------------------------------------------------------------------------
def parse_agencyDF_fromClass(agency_obj):
    data = {'agency_id': [agency_obj.agency_id],
            'agency_name': [agency_obj.agency_name],
            'agency_url': [agency_obj.agency_url],
            'agency_timezone': [agency_obj.agency_timezone],
            'agency_lang': [agency_obj.agency_lang],
            'agency_phone': [agency_obj.agency_phone],
            'agency_fare_url': [agency_obj.agency_fare_url]}
    parsed_df = pandas.DataFrame(data, columns=["agency_id", "agency_name", "agency_url", "agency_timezone", "agency_lang", "agency_phone", "agency_fare_url"])
    return parsed_df
# END agency.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START calendar.txt -------------------------------------------------------------------------------------------------------------------------------------------------------
def parse_calendarDF_fromClass(calendar_obj):
    data = {'service_id': [calendar_obj.service_id],
            'monday': [calendar_obj.monday],
            'tuesday': [calendar_obj.tuesday],
            'wednesday': [calendar_obj.wednesday],
            'thursday': [calendar_obj.thursday],
            'friday': [calendar_obj.friday],
            'saturday': [calendar_obj.saturday],
            'sunday': [calendar_obj.sunday],
            'start_date': [calendar_obj.start_date],
            'end_date': [calendar_obj.end_date]}
    parsed_df = pandas.DataFrame(data, columns=["service_id", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "start_date", "end_date"])
    return parsed_df
# END calendar.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START routes.txt -------------------------------------------------------------------------------------------------------------------------------------------------------
def parse_routesDF_fromClass(routes_obj):
    data = {'route_id': [routes_obj.route_id],
            'route_short_name': [routes_obj.route_short_name],
            'route_long_name': [routes_obj.route_long_name],
            'route_type': [routes_obj.route_type],
            'route_color': [routes_obj.route_color],
            'route_text_color': [routes_obj.route_text_color],
            'agency_id': [routes_obj.agency_id]}
    parsed_df = pandas.DataFrame(data, columns=["route_id", "route_short_name", "route_long_name", "route_type", "route_color", "route_text_color", "agency_id"])
    return parsed_df
# END routes.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START stops.txt -------------------------------------------------------------------------------------------------------------------------------------------------------
def parse_stopsDF_fromListOfClass(list_of_stops):
    parsed_df = pandas.DataFrame(columns=["stop_id", "stop_name", "stop_lat", "stop_lon", "zone_id", "location_type", "wheelchair_boarding"])
    list_of_df = []
    for stop_obj in tqdm(list_of_stops):
        data = {'stop_id': [stop_obj.stop_id],
                'stop_name': [stop_obj.stop_name],
                'stop_lat': [stop_obj.stop_lat],
                'stop_lon': [stop_obj.stop_lon],
                'zone_id': [stop_obj.zone_id],
                'location_type': [stop_obj.location_type],
                'wheelchair_boarding': [stop_obj.wheelchair_boarding]}
        indv_stopDF = pandas.DataFrame(data, columns=["stop_id", "stop_name", "stop_lat", "stop_lon", "zone_id", "location_type", "wheelchair_boarding"])
        list_of_df.append(indv_stopDF)
    parsed_df = pandas.concat(list_of_df)
    return parsed_df
# END stops.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START trips.txt -------------------------------------------------------------------------------------------------------------------------------------------------------
def parse_tripsDF_fromListOfClass(list_of_trips):
    parsed_df = pandas.DataFrame(columns=["trip_id", "route_id", "service_id", "direction_id", "trip_headsign", "trip_short_name", "block_id", "shape_id"])
    list_of_df = []
    for stop_obj in list_of_trips:
        data = {'trip_id': [stop_obj.trip_id],
                'route_id': [stop_obj.route_id],
                'service_id': [stop_obj.service_id],
                'direction_id': [stop_obj.direction_id],
                'trip_headsign': [stop_obj.trip_headsign],
                'trip_short_name': [stop_obj.trip_short_name]}
        indv_tripDF = pandas.DataFrame(data, columns= ["trip_id", "route_id", "service_id", "direction_id", "trip_headsign", "trip_short_name", "block_id", "shape_id"])
        list_of_df.append(indv_tripDF)
    parsed_df = pandas.concat(list_of_df)
    return parsed_df
# END trips.txt -------------------------------------------------------------------------------------------------------------------------------------------------------


# START stop_times.txt -------------------------------------------------------------------------------------------------------------------------------------------------------
def parse_stoptimesDF_fromListOfClass(list_of_stoptimes):
    parsed_df = pandas.DataFrame(columns=["stop_id", "trip_id", "arrival_time", "departure_time", "stop_sequence", "stop_headsign", "drop_off_type", "pickup_type"])
    list_of_df = []
    for stoptimes_obj in list_of_stoptimes:
        data = {'stop_id': [stoptimes_obj.stop_id],
                'trip_id': [stoptimes_obj.trip_id],
                'arrival_time': [stoptimes_obj.arrival_time],
                'departure_time': [stoptimes_obj.departure_time],
                'stop_sequence': [stoptimes_obj.stop_sequence],
                'stop_headsign': [stoptimes_obj.stop_headsign],
                'drop_off_type': [stoptimes_obj.drop_off_type],
                'pickup_type': [stoptimes_obj.pickup_type]}
        indv_stoptimesDF = pandas.DataFrame(data, columns=["stop_id", "trip_id", "arrival_time", "departure_time", "stop_sequence", "stop_headsign",
                                                           "drop_off_type", "pickup_type"])
        list_of_df.append(indv_stoptimesDF)
    parsed_df = pandas.concat(list_of_df)
    return parsed_df
# END stop_times.txt -------------------------------------------------------------------------------------------------------------------------------------------------------




################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################

# ================ Step 2.a GENERAL DF -> Class Object(s) -> INDV DFs  =========================================================================================
################################################################################################################################################################



# START agency.txt ---------------------------------------------------------------------------------------------------------------------------------------------
def parse_agency_fromGDF(general_input_dataframe):
    # Parses a Pandas DataFrame containing information for 'agency.txt' into an Agency class object
    agency_id = general_input_dataframe['agency_id'][0]
    agency_name = general_input_dataframe['agency_name'][0]
    agency_url = general_input_dataframe['agency_url'][0]
    agency_timezone = general_input_dataframe['agency_timezone'][0]
    agency_lang = None
    agency_phone = None
    agency_fare_url = None
    new_agency = Agency(agency_id, agency_name, agency_url, agency_timezone, agency_lang, agency_phone, agency_fare_url)
    print("\t [+] ['agency.txt'] GDF -> Agency DF")
    return parse_agencyDF_fromClass(new_agency)
# END agency.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START calendar.txt -----------------------------------------------------------------------------------------------------------------------------------------------------
def parse_calendar_fromGDF(general_input_dataframe):
    # Parses a Pandas DataFrame containing information for 'calendar.txt' into an Calendar class object
    service_id = general_input_dataframe['service_id'][0]
    monday = general_input_dataframe['monday'][0]
    tuesday = general_input_dataframe['tuesday'][0]
    wednesday = general_input_dataframe['wednesday'][0]
    thursday = general_input_dataframe['thursday'][0]
    friday = general_input_dataframe['friday'][0]
    saturday = general_input_dataframe['saturday'][0]
    sunday = general_input_dataframe['sunday'][0]
    start_date = general_input_dataframe['start_date'][0]
    end_date = general_input_dataframe['end_date'][0]
    new_calendar = Calendar(service_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, start_date, end_date)
    print("\t [+] ['calendar.txt'] GDF -> Agency DF")
    return parse_calendarDF_fromClass(new_calendar) # Output DF containing cleaned Calendar class object
# END calendar.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START routes.txt -----------------------------------------------------------------------------------------------------------------------------------------------------
def parse_routes_fromGDF(general_input_dataframe):
    # Parses a Pandas DataFrame containing information for 'calendar.txt' into an Routes class object
    route_id = general_input_dataframe['route_id'][0]
    route_short_name = general_input_dataframe['route_short_name'][0]
    route_long_name = general_input_dataframe['route_long_name'][0]
    route_type = general_input_dataframe['route_type'][0]
    route_color = general_input_dataframe['route_color'][0]
    route_text_color = general_input_dataframe['route_text_color'][0]
    agency_id = general_input_dataframe['agency_id'][0]
    new_routes = Routes(route_id, route_short_name, route_long_name, route_type, route_color, route_text_color, agency_id)
    print("\t [+] ['routes.txt'] GDF -> Agency DF")
    return parse_routesDF_fromClass(new_routes)  # Output DF containing cleaned Routes class object
# END routes.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START stops.txt -----------------------------------------------------------------------------------------------------------------------------------------------------
def parse_stops_fromGDF(stops_input_dataframe):
    # Parses a Pandas DataFrame containing information for 'stops.txt' into an Stops class object
    list_stops = []
    for index, row in stops_input_dataframe.iterrows():
        stop_id = row['stop_id']
        stop_name = row['stop_name']
        stop_lat = row['stop_lat']
        stop_lon = row['stop_lon']
        zone_id = row['zone_id']
        location_type = row['location_type']
        wheelchair_boarding = row['wheelchair_boarding']
        new_stop = Stops(stop_id, stop_name, stop_lat, stop_lon, zone_id, location_type, wheelchair_boarding)
        list_stops.append(new_stop)

    print("\t [+] ['stops.txt'] GDF -> Agency DF")
    return parse_stopsDF_fromListOfClass(list_stops)  # Output DF containing cleaned Stops class object
# END stops.txt -------------------------------------------------------------------------------------------------------------------------------------------------------

# START trips.txt -----------------------------------------------------------------------------------------------------------------------------------------------------
def parse_trips_fromGDF(general_input_dataframe, stops_input_dataframe):
    # Constants
    two_way = ["0", "1"]
    list_trips = []

    # User Input
    start_time_dir0_seconds = to_seconds(general_input_dataframe['start_time_dir0'][0])
    start_time_dir1_seconds = to_seconds(general_input_dataframe['start_time_dir1'][0])
    headways = to_seconds(general_input_dataframe['headways'][0])

    start_period_seconds = to_seconds(general_input_dataframe['start_of_period'][0])
    end_period_seconds = to_seconds(general_input_dataframe['end_of_period'][0])
    oneway_twoway = int(general_input_dataframe['oneway_twoway'][0])

    # Generated
    num_trips_dir0 = math.floor((end_period_seconds - start_time_dir0_seconds) / headways)  # (End of Period - Start_time_dir0) / headways
    num_trips_dir1 = math.floor((end_period_seconds - start_time_dir1_seconds) / headways)  # (End of Period - Start_time_dir0) / headways

    # Start looping to create classes
    if oneway_twoway == 2:
        for direction in two_way:
            if direction == "0":
                for i in tqdm(range(num_trips_dir0)):
                    direction_id = direction
                    route_id = general_input_dataframe['route_id'][0]
                    service_id = general_input_dataframe['service_id'][0]
                    trip_headsign = stops_input_dataframe['stop_name'][stops_input_dataframe.last_valid_index()]
                    trip_id = route_id+"_"+str(1001+i)
                    new_trip = Trips(trip_id, route_id, service_id, direction_id, trip_headsign, None, None, None, None, None, None)
                    list_trips.append(new_trip)
            elif direction == "1":
                for i in tqdm(range(num_trips_dir1)):
                    direction_id = direction
                    route_id = general_input_dataframe['route_id'][0]
                    service_id = general_input_dataframe['service_id'][0]
                    trip_headsign = stops_input_dataframe['stop_name'][0]
                    trip_id = route_id+"_"+str(2001+i)
                    new_trip = Trips(trip_id, route_id, service_id, direction_id, trip_headsign, None, None, None, None, None, None)
                    list_trips.append(new_trip)
    elif oneway_twoway == 1:
        for i in tqdm(range(num_trips_dir0)):
            direction_id = 0
            route_id = general_input_dataframe['route_id'][0]
            service_id = general_input_dataframe['service_id'][0]
            trip_headsign = stops_input_dataframe['stop_name'][stops_input_dataframe.last_valid_index()]
            trip_id = route_id+"_"+str(1001+i)
            new_trip = Trips(trip_id, route_id, service_id, direction_id, trip_headsign, None, None, None, None, None, None)
            list_trips.append(new_trip)
    print("\t [+] ['trips.txt'] GDF -> Agency DF")
    return parse_tripsDF_fromListOfClass(list_trips)
# END trips.txt -----------------------------------------------------------------------------------------------------------------------------------------------------


# START stop_times.txt -----------------------------------------------------------------------------------------------------------------------------------------------------
def parse_stoptimes_fromGDF(general_df, stops_df):
    # Constants
    list_stoptimes = []
    two_way = ["0", "1"]
    start_time_dir0_seconds = to_seconds(general_df['start_time_dir0'][0])
    start_time_dir1_seconds = to_seconds(general_df['start_time_dir1'][0])
    headways = to_seconds(general_df['headways'][0])

    start_period_seconds = to_seconds(general_df['start_of_period'][0])
    end_period_seconds = to_seconds(general_df['end_of_period'][0])
    oneway_twoway = int(general_df['oneway_twoway'][0])


    # Generated
    num_trips_dir0 = math.floor((end_period_seconds - start_time_dir0_seconds) / headways)  # (End of Period - Start_time_dir0) / headways
    num_trips_dir1 = math.floor((end_period_seconds - start_time_dir1_seconds) / headways)  # (End of Period - Start_time_dir0) / headways
    # Iterate through all trips/stops
    if oneway_twoway == 2:
        for direction in two_way: # Iterate through both directions: "0" or "1"
            if direction == "0":
                initial_start_period = start_time_dir0_seconds
                start_arrival_time = initial_start_period
                for indv_trip in tqdm(range(num_trips_dir0)): # Iterate through all trips in dir0\
                    time_passed = 0
                    for indv_stop in tqdm(range(len(stops_df))):
                        # Generate variables
                        stop_id = stops_df['stop_id'][indv_stop]
                        route_id = general_df['route_id'][0]
                        trip_id = route_id+"_"+str(1001+indv_trip)
                        arrival_time = to_datetime(start_arrival_time + time_passed)
                        departure_time = arrival_time
                        stop_sequence = indv_stop + 1
                        new_stoptimes = StopTimes(stop_id, trip_id, arrival_time, departure_time, stop_sequence, None, None, None)
                        list_stoptimes.append(new_stoptimes)
                        # Changes
                        if stop_sequence != len(stops_df):
                            time_between = stops_df['time_between'][indv_stop]
                            time_passed += to_seconds(time_between)

                    start_arrival_time += headways
            elif direction == "1":
                initial_start_period = start_time_dir1_seconds
                start_arrival_time = initial_start_period
                for indv_trip in tqdm(range(num_trips_dir1)):  # Iterate through all trips in dir0\
                    time_passed = 0
                    counter = 0
                    stops_counter = stops_df.last_valid_index() - 1
                    for indv_stop in tqdm(reversed(range(len(stops_df)))):
                        # Generate variables
                        stop_id = stops_df['stop_id'][indv_stop]
                        route_id = general_df['route_id'][0]
                        trip_id = route_id+"_"+str(2001+indv_trip)
                        arrival_time = to_datetime(start_arrival_time + time_passed)
                        departure_time = arrival_time
                        stop_sequence = counter + 1
                        new_stoptimes = StopTimes(stop_id, trip_id, arrival_time, departure_time, stop_sequence, None, None, None)
                        list_stoptimes.append(new_stoptimes)
                        counter += 1
                        # # Changes
                        if str(stops_df['time_between'][stops_counter]) == 'nan':
                            time_between = "0:00:00"
                        else:
                            time_between = stops_df['time_between'][stops_counter]
                        time_passed += to_seconds(time_between)
                        if stops_counter > 0:
                            stops_counter -= 1
                    start_arrival_time += headways
    elif oneway_twoway == "1":
        initial_start_period = start_time_dir0_seconds
        start_arrival_time = initial_start_period
        for indv_trip in tqdm(range(num_trips_dir0)): # Iterate through all trips in dir0\
            time_passed = 0
            for indv_stop in tqdm(range(len(stops_df))):
                # Generate variables
                stop_id = stops_df['stop_id'][indv_stop]
                route_id = general_df['route_id'][0]
                trip_id = route_id+"_"+str(1001+indv_trip)
                arrival_time = to_datetime(start_arrival_time + time_passed)
                departure_time = arrival_time
                stop_sequence = indv_stop + 1
                stop_name = stops_df['stop_name'][indv_stop]
                new_stoptimes = StopTimes(stop_id, trip_id, arrival_time, departure_time, stop_sequence, None, None, None)
                list_stoptimes.append(new_stoptimes)
                # Changes
                if stop_sequence != len(stops_df):
                    time_between = stops_df['time_between'][indv_stop]
                    time_passed += to_seconds(time_between)

            start_arrival_time += headways

    print("\t [+] ['stop_times.txt'] GDF -> Agency DF")
    return parse_stoptimesDF_fromListOfClass(list_stoptimes)

# END stop_times.txt -----------------------------------------------------------------------------------------------------------------------------------------------------