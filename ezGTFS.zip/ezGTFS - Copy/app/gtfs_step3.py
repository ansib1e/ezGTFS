import pandas


import os
# Initiate output filepaths
# Test OS
dirname = os.path.dirname(__file__)
if not os.path.exists('../output_GTFS'):
    os.makedirs('../output_GTFS')

# Initiate final DataFrames to be outputted to CSV
# The columns here determine the output columns in the csv
empty_agency_df = pandas.DataFrame(columns=["agency_id", "agency_name", "agency_url", "agency_timezone", "agency_lang", "agency_phone", "agency_fare_url"])
empty_calendar_df = pandas.DataFrame(columns=["service_id", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "start_date", "end_date"])
empty_routes_df = pandas.DataFrame(columns=["route_id", "route_short_name", "route_long_name", "route_type", "route_color", "route_text_color", "agency_id"])
empty_stops_df = pandas.DataFrame(columns=["stop_id", "stop_name", "stop_lat", "stop_lon", "zone_id", "location_type", "wheelchair_boarding"])
emtpy_trips_df = pandas.DataFrame(columns=["trip_id", "route_id", "service_id", "direction_id", "trip_headsign", "trip_short_name", "block_id", "shape_id"])
empty_stoptimes_df = pandas.DataFrame(columns=["stop_id", "trip_id", "arrival_time", "departure_time", "stop_sequence", "stop_headsign", "drop_off_type", "pickup_type"])

def parse_outputCSV_from_indvDF(parsed_indv_df, dataset, choice):
    if not os.path.exists('../output_GTFS/'+choice):
        os.makedirs('../output_GTFS/'+choice)

    if dataset == 'agency.txt':
        # ---------------------------------- 'agency'.txt----------------------------------
        output_agency_path = '../output_GTFS/'+choice+'/agency.csv'
        cleaned_agency_df = empty_agency_df.append(parsed_indv_df)
        print("\t[*] [agency.txt] Agency DF -> Output CSV")
        print('\t\t[*] Writing final output to: {} ...'.format(output_agency_path))
        cleaned_agency_df.to_csv(output_agency_path, index=False)
        print("\t\t[+] SUCCESSFULLY WRITTEN to: {} ...\n\t\t[!] Created 'agency.csv'...".format(output_agency_path))
    elif dataset == 'calendar.txt':
        # ---------------------------------- 'calendar'.txt----------------------------------
        cleaned_calendar_df = empty_calendar_df.append(parsed_indv_df)
        output_calendar_path = '../output_GTFS/'+choice+'/calendar.csv'

        print("\t[*] [calendar.txt] Calendar DF -> Output CSV")
        print('\t\t[*] Writing final output to: {} ...'.format(output_calendar_path))
        cleaned_calendar_df.to_csv(output_calendar_path, index=False)
        print("\t\t[+] SUCCESSFULLY WRITTEN to: {} ...\n\t\t[!] Created 'calendar.csv'...".format(output_calendar_path))
    elif dataset == 'routes.txt':
        # ---------------------------------- 'routes'.txt----------------------------------
        output_routes_path = '../output_GTFS/'+choice+'/routes.csv'

        cleaned_routes_df = empty_routes_df.append(parsed_indv_df)
        print("\t[*] [routes.txt] Routes DF -> Output CSV")
        print('\t\t[*] Writing final output to: {} ...'.format(output_routes_path))
        cleaned_routes_df.to_csv(output_routes_path, index=False)
        print("\t\t[+] SUCCESSFULLY WRITTEN to: {} ...\n\t\t[!] Created 'routes.csv'...".format(output_routes_path))
    elif dataset == 'stops.txt':
        # ---------------------------------- 'stops'.txt----------------------------------
        output_stops_path = '../output_GTFS/'+choice+'/stops.csv'

        cleaned_stops_df = empty_stops_df.append(parsed_indv_df)
        print("\t[*] [stops.txt] Stops DF -> Output CSV")
        print('\t\t[*] Writing final output to: {} ...'.format(output_stops_path))
        cleaned_stops_df.to_csv(output_stops_path, index=False)
        print("\t\t[+] SUCCESSFULLY WRITTEN to: {} ...\n\t\t[!] Created 'stops.csv'...".format(output_stops_path))
    elif dataset == 'trips.txt':
        # ---------------------------------- 'trips'.txt----------------------------------
        output_trips_path = '../output_GTFS/'+choice+'/trips.csv'
        cleaned_trips_df = emtpy_trips_df.append(parsed_indv_df)
        print("\t[*] [trips.txt] Trips DF -> Output CSV")
        print('\t\t[*] Writing final output to: {} ...'.format(output_trips_path))
        cleaned_trips_df.to_csv(output_trips_path, index=False)
        print("\t\t[+] SUCCESSFULLY WRITTEN to: {} ...\n\t\t[!] Created 'trips.csv'...".format(output_trips_path))
    elif dataset == "stop_times.txt":
        # ---------------------------------- 'stop_times'.txt----------------------------------
        output_stoptimes_path = '../output_GTFS/'+choice+'/stop_times.csv'
        cleaned_stoptimes_df = empty_stoptimes_df.append(parsed_indv_df)
        print("\t[*] [stop_times.txt] StopTimes DF => Output CSV")
        print('\t\t[*] Writing final output to: {} ...'.format(output_stoptimes_path))
        cleaned_stoptimes_df.to_csv(output_stoptimes_path, index=False)
        print("\t\t[+] SUCCESSFULLY WRITTEN to: {} ...\n\t\t[!] Created 'stop_times.csv'...".format(output_stoptimes_path))
