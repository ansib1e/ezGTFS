import os

def csv_to_text(user_choice):
    folder_path = '../output_GTFS/'+user_choice+"/"
    print("\t[*] CSV -> TXT")
    print('\t\t[*] Writing final output to: {} ...'.format(folder_path))
    for file in os.listdir(folder_path):  # use the directory name here
        file_name, file_ext = os.path.splitext(file)
        output = open(folder_path+file_name+".txt", 'a')
        with open(folder_path+file_name+".csv", "rt", encoding='ascii') as f:
            for row in f:
                output.write(row)
    output.close()
    f.close()
    print("\t[!] Completed conversion to .txt from .csv ...")
    return


def delete_csv_final_step(user_choice):
    folder_path = '../output_GTFS/'+user_choice+"/"
    print("\t[*] Deleting .csv files....")
    print('\t\t[*] Deleting .csv output files in: {} ...'.format(folder_path))
    for file in os.listdir(folder_path):
        file_name, file_ext = os.path.splitext(file)
        if file_ext == ".csv":
            os.remove(folder_path+file)
    print("\t[!] Completed deleting all .csv files ...")